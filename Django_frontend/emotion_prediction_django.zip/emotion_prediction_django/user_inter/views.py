from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from django.urls import reverse_lazy
from django.views import generic
from django.http import HttpResponse
from . import models
from django.shortcuts import render, redirect
from .forms import SignUpForm
from django.contrib.auth import login, authenticate
from .forms import SignUpForm


def home(request):
    return render(request, "home.html")

def signup(request):
    if request.method == "POST":
        user_info= {'name': request.POST['name'],'surname': request.POST['surname'],'email': request.POST['email'],'password': request.POST['psw']}
        print(user_info)
        return render(request, "settings.html")

    else:
       return render(request, "signup.html")

def login_user(request):
    user_info=models.User_info.objects.all()
    c={"entry_user": user_info}
    return render(request, 'registration/login.html', c)

def print_from_button(request):
    if(request.GET.get('print_btn')):
        print("hello")
        print('Button clicked')
    return render(request, 'welcome.html',{'value':'Button clicked'})

def user_state(request):
    if request.method == "POST":
        user_state_g={'gender': request.POST['gender'], 'age': request.POST['age'], 'workstatus':request.POST['workstatus'],
                      'leisureact':request.POST.getlist('leisureact'),'timewith':request.POST.getlist('timewith'),
                      'reasonevents':request.POST['reasonevents'], 'cuisine': request.POST.getlist('cuisine'),'music': request.POST.getlist('music'),
                      'movie':request.POST.getlist('movie'), 'weather':request.POST['weather'], 'children':request.POST['children'],
                      'mood': request.POST['mood'], 'animal': request.POST['animal'], 'sad-eating':request.POST['sad-eating'],
                      'sad-talk':request.POST['sad-talk'], 'sad-music':request.POST['sad-music'],'sad-activity':request.POST['sad-activity'],
                      'sad-alone':request.POST['sad-alone'], 'angry-eating': request.POST['angry-eating'], 'angry-talk':request.POST['angry-talk'],
                      'angry-music':request.POST['angry-music'], 'angry-activity':request.POST['angry-activity'], 'angry-alone':request.POST['angry-alone'],
                      'happy-eating': request.POST['happy-eating'], 'happy-talk': request.POST['happy-talk'],
                      'happy-music': request.POST['happy-music'], 'happy-activity': request.POST['happy-activity'],
                      'happy-alone': request.POST['happy-alone'],
                      }
        print(user_state_g)
        return render(request, "welcome.html")
    else:
        return render(request, "questions.html")