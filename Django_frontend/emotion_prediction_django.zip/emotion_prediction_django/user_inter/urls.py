from django.urls import path,include
from django.views.generic.base import TemplateView
from django.contrib import admin
from . import views

urlpatterns = [
    path('login/', TemplateView.as_view(template_name='registration/login.html'), name='login'),
    path('login/', include('django.contrib.auth.urls')),
    path('login/', views.login_user),
    path('signup/', views.signup, name="signup"),
    #path('questions/', TemplateView.as_view(template_name='questions.html'), name='questions'),
    path('questions/', views.user_state, name="user_state"),
    path('welcome/', TemplateView.as_view(template_name='welcome.html')),
    path('welcome/', views.print_from_button),
    path('signup/settings/', TemplateView.as_view(template_name='settings.html')),
    #path('signup/', include('django.contrib.auth.urls')),

]
