from pymongo import MongoClient
from user_inter import views
import random
import numpy
import googlemaps
import datetime
import requests
from bson import ObjectId

location=[40.927002,29.122570]
location2=[40.927045,29.123308]
location3=[40.919204,29.165346]
location4=[41.0136185,29.0903482]
location5=[41.900034,28.00043]
location6=[	40.9031004,29.154147]
fast_food_restaurants=["Burger King","KFC","MCDonald's","Popeyes","Arby's"]
fast_food_types=["fast food","fast&food"]

client = MongoClient()
user_state_graph_db=client["user-db"]
user_info=user_state_graph_db.user_info
weather_activities={1:["walking","travelling","reading","friends","shopping"],
            0:["reading","home","friends","internet","movie"]}
alone_activities={"watching":0.25,"surfing on the internet":0.25,"taking a nap":0.25,"going for a walk":0.25}
music_db={"pop":{"Sucker":"Jonas Brothers","Dancing With A Stranger":"Sam Smith & Normani",
                 "Break Up With Your Girlfriend, I'm Bored":"Ariana Grande","Sweet But Psycho":"Ava Max","7 Rings":"Ariana Grande",
                 "Wow":"Post Malone","Without Me":"Halsey","Eastside":"benny blanco, Halsey & Khalid",
                 "Close To Me":"Ellie Goulding X Diplo Featuring Swae Lee","Better":"Khalid"},
          "rap":{"Old Town Road":"Lil Nas X Featuring Billy Ray Cyrus","Wow.":"Post Malone","Middle Child":"J. Cole",
                 "Going Bad":"Meek Mill Featuring Drake","Please Me":"Cardi B & Bruno Mars","A Lot":"21 Savage",
                 "Pure Water":"Mustard & Migos"}}
movie_db={"Action":["Eye of the Tiger","Electric Slide"],"Comedy":["Krystal","I Saw What You Did"],
          "Crime":["Victims","Shallow Grave"],"Horror":["Slaughter of the Innocents","A Nightmare on Elm Street"],
          "Science Fiction":["Robot Stories","Back to the Future"]}

music_preference=[]
movie_preference=[]
food_preference=[]
activity_preference=[]
general_infos={}
other_infos={}
answers={}
user_infos={}
current_id={}

def sign_up(sign_up_info):
    email_info={}
    email_info["email"]=sign_up_info["email"]
    check_email=user_info.find_one(email_info)
    if check_email!=None:
        return 0
    else:
        current_id["_id"]=user_info.find_one({"email":sign_up_info["email"]})
        return 1

def check_infos(log_info):
    valid_dict = user_info.find_one(log_info)
    if valid_dict == None:
        return 0
    else:
        current_id["_id"] = valid_dict["_id"]
        return 1

def get_user_info(music,movie,food,activity,general_info,other_info,answer,userinfo):
    music_preference.extend(music)
    movie_preference.extend(movie)
    food_preference.extend(food)
    activity_preference.extend(activity)
    general_infos.update(general_info)
    other_infos.update(other_info)
    answers.update(answer)
    user_infos.update(userinfo)
    form_graph(user_infos)

def form_activities():
    activity_preference_probs={}
    probabilities=1/len(activity_preference)
    for i in activity_preference:
        activity_preference_probs[i]=probabilities
    return activity_preference_probs


def form_graph(userinfos):
    user_state_graph_db = client["user-db"]
    user_info = user_state_graph_db.user_info
    information={}
    for i in answers:
        list=[]
        for k in answers[i]:
            list.append(k/sum(answers[i]))
        information[i]={"food":list[0], "friend":list[1], "music":list[2], "activities":list[3], "alone":list[4]}
    averages={}
    for key in information:
        for i in information[key]:
            if i not in averages:
                averages[i]=information[key][i]
            else:
                averages[i]+=information[key][i]
    for key in averages:
        averages.update({key:averages[key]/3})
    information.update({"neutral":averages})
    information.update({"general_infos":general_infos,"music_preference":music_preference,
                        "movie_preference":movie_preference,"food_preference":food_preference,
                        "activity_preference":form_activities(),"alone_activities":alone_activities,
                        "other_infos":other_infos})
    information.update(userinfos)
    user_info.insert_one(information)
    print(user_info.find_one(current_id))



def get_place_info(loc):
    gmaps = googlemaps.Client(key='AIzaSyC_sErEr3yZ8OwXsUkKipwYuYzy4cpeA6Y')
    current_location=gmaps.places(location=loc,query="food restaurant")
    results=current_location["results"]
    for i in results:
        i.pop("icon"),i.pop("id"),i.pop("reference"),i.pop("place_id"),i.pop("user_ratings_total"),i.pop("plus_code")
    for key in results:
        if key["name"]in fast_food_restaurants or "fast food" in key["name"].lower() or "fast&food" in key["name"].lower():
            key.update({"food_type":"fast food"})
        else:
            key.update({"food_type":"unkonwn"})
    place_dict={}
    for i in results:
        place_location=[i["geometry"]["location"]["lat"],i["geometry"]["location"]["lng"]]
        dist = numpy.linalg.norm(numpy.array(loc)-numpy.array(place_location))
        place_dict[dist]=i["name"],i["food_type"]
    places={}
    for i in sorted(place_dict):
        places[place_dict[i][0]]=place_dict[i][1]
    return(places)


def get_weather_data():
    r = requests.get("https://api.openweathermap.org/data/2.5/forecast?lat=41.013517&lon=29.090249&appid=22af8c91b1a26ca5f79c8345e283edee")
    weather_data=r.json()["list"]
    temp_and_weather={}
    temp_and_weather[weather_data[0]["weather"][0]["main"]]=int(weather_data[0]["main"]["temp"]-273)
    for key in temp_and_weather:
        if key!="Clouds" and temp_and_weather[key]>=16:
            return 1
        else:
            return 0

"""
def feedback(emotion, suggestion):
    current_probs = user_info.find_one(current_id)[emotion]
    other_activities = user_info.find_one(current_id)[suggestion[-1]]
    new_activities = {}
    new_probs = {}
    if len(suggestion) == 1:
        general_feedback = float(input("How much did you like this suggestion? "))
        new_suggestion_prob = (general_feedback * current_probs[suggestion[0]]) + current_probs[suggestion[0]]
        for key in current_probs:
            if key == suggestion[0]:
                new_probs[suggestion[0]] = new_suggestion_prob
            else:
                new_probs[key] = current_probs[key] + (
                            (current_probs[suggestion[0]] - new_suggestion_prob) / (len(current_probs) - 1))
        user_info.update_one(current_id, {"$set": {emotion: new_probs}})
    else:
        the_feedback = float(input("How much did you like " + suggestion[1] + " suggestion? "))
        general_feedback = float(input("How much did you like the suggestion itself? "))
        new_suggestion_prob = (general_feedback * current_probs[suggestion[0]]) + current_probs[suggestion[0]]
        for key in current_probs:
            if key == suggestion[0]:
                new_probs[suggestion[0]] = new_suggestion_prob
            else:
                new_probs[key] = current_probs[key] + (
                            (current_probs[suggestion[0]] - new_suggestion_prob) / (len(current_probs) - 1))
        user_info.update_one(current_id, {"$set": {emotion: new_probs}})
        new_act_prob = (the_feedback * other_activities[suggestion[1]]) + other_activities[suggestion[1]]
        for key in other_activities:
            if key == suggestion[1]:
                new_activities[suggestion[1]] = new_act_prob
            else:
                new_activities[key] = other_activities[key] + (
                            (other_activities[suggestion[1]] - new_act_prob) / (len(other_activities) - 1))
        user_info.update_one(current_id, {"$set": {suggestion[-1]: new_activities}})

def activities(emotion,weather):
    final_suggestion_feedback=[]
    preferred_activities=user_info.find_one(current_id)["activity_preference"]
    common_activities=list(set(weather_activities[weather]).intersection(list(preferred_activities.keys())))
    possible_suggestions={}
    max_prob=max(list(preferred_activities.values()))
    for i in preferred_activities:
        if preferred_activities[i]==max_prob:
            possible_suggestions[i]=preferred_activities[i]
    the_suggestion=random.choice(list(possible_suggestions.keys()))
    final_suggestion_feedback.extend(["activities",the_suggestion,"activity_preference"])
    print("I think you wouldn't say no to some activities right now. What about "+the_suggestion+"?")
    return feedback(emotion,final_suggestion_feedback)


def alone(emotion):
    final_suggestion_feedback=[]
    preferences=[]
    max_prob=max(list(alone_activities.values()))
    for key in alone_activities:
        if alone_activities[key]==max_prob:
            preferences.append(key)
    alone_activity=random.choice(preferences)
    movie_sug=""
    if alone_activity=="watching":
        m_type=random.choice(movie_preference)
        movie_sug=" "+m_type+" movie, like "+random.choice(movie_db[m_type])
    final_suggestion_feedback.extend(["alone",alone_activity,"alone_activities"])
    print("You may want to be alone right now. How about "+alone_activity+movie_sug+" when you're alone?")
    return feedback(emotion,final_suggestion_feedback)

def food(emotion):
    final_suggestion_feedback=[]
    nearby_restaurants=get_place_info(location4)
    restaurants={}
    for key in nearby_restaurants:
        if nearby_restaurants[key] in food_preference:
            restaurants[key]=nearby_restaurants[key]
    if len(restaurants)==0:
        print("I know that you like fast food but there is no restaurant around you which serve these type foods. So what about cook yourself? :)")
    else:
        the_choice=random.choice(list(restaurants.keys()))
    final_suggestion_feedback.append("food")
    print("There is "+the_choice+" close to you and it serves "+restaurants[the_choice]+" just like your type. What about going there and eat something delicious? :)")
    return feedback(emotion,final_suggestion_feedback)

def music(emotion):
    final_suggestion_feedback = []
    music_pref = random.choice(music_preference)
    music_sugg = random.choice(list(music_db[music_pref].keys()))
    final_suggestion_feedback.append("music")
    print("As I remember, you like " + music_pref + " songs. So what about listening " + music_sugg + " by " +
          music_db[music_pref][music_sugg] + "?")
    return feedback(emotion, final_suggestion_feedback)

def friend(emotion):
    final_suggestion_feedback=[]
    final_suggestion_feedback.append("friend")
    print("I see that you feel "+emotion+" right now. What about sharing your feelings with your friend?")
    return feedback(emotion,final_suggestion_feedback)

def return_suggestion(emotion):
    emotion=emotion
    weather=get_weather_data()
    possible_suggestions=[]
    current_emotion=user_info.find_one(current_id)[emotion]
    current_emotion.update({"activities":current_emotion["activities"]+(current_emotion["activities"]*user_info.find_one(current_id)["general_infos"]["weather preference"]*weather)})
    max_prob=max(list(current_emotion.values()))
    for key in current_emotion:
        if current_emotion[key]==max_prob:
            possible_suggestions.append(key)
    final_suggestion= random.choice(possible_suggestions)
    if final_suggestion=="activities":
        activities(emotion,weather)
    elif final_suggestion=="alone":
        alone(emotion)
    elif final_suggestion=="food":
        food(emotion)
    elif final_suggestion=="music":
        music(emotion)
    else:
        friend(emotion)
return_suggestion("happy")
"""




