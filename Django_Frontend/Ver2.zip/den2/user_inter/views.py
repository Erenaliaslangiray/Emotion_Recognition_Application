from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from django.urls import reverse_lazy
from django.views import generic
from django.http import HttpResponse
from . import models
from django.shortcuts import render, redirect
from .forms import SignUpForm
from django.contrib.auth import login, authenticate
from .forms import SignUpForm
from user_inter import user_state_graph
sign_up_infos={}

def home(request):
    return render(request, "home.html")

def signup(request):
    if request.method == "POST":
        user_info= {'name': request.POST['name'],'surname': request.POST['surname'],'email': request.POST['email'],'password': request.POST['psw']}
        if user_state_graph.sign_up(user_info)==1:
            sign_up_infos.update(user_info)
            return render(request, "settings.html")
        else:
            return render(request,"signup.html")
    else:
       return render(request, "signup.html")

def login_user(request):
    if request.method == "POST":
        login_info={"email":request.POST['email'],"password":request.POST['psw']}
        if user_state_graph.check_infos(login_info)==1:
            return render(request,"welcome.html")
        else:
            return render(request,"registration/login.html")
    else:
        return render(request, "registration/login.html")

def print_from_button(request):
    if(request.GET.get('print_btn')):
        print("hello")
        print('Button clicked')
    return render(request, 'welcome.html',{'value':'Button clicked'})

def user_state(request):
    if request.method == "POST":
        music_preference_list=request.POST.getlist('music')
        movie_preference_list=request.POST.getlist('movie')
        food_preference_list=request.POST.getlist('cuisine')
        activity_preference_list=request.POST.getlist('leisureact')
        answers={"sad":[int(request.POST['sad-eating']),int(request.POST['sad-talk']),int(request.POST['sad-music']),int(request.POST['sad-activity']),int(request.POST['sad-alone'])],
                 "angry":[int(request.POST['angry-eating']),int(request.POST['angry-talk']),int(request.POST['angry-music']),int(request.POST['angry-activity']),int(request.POST['angry-alone'])],
                 "happy":[int(request.POST['happy-eating']),int(request.POST['happy-talk']),int(request.POST['happy-music']),int(request.POST['happy-activity']),int(request.POST['happy-alone'])]}
        general_infos={"animal":float(request.POST['animal']), "music":float(request.POST['mood']),"children":float(request.POST['children']),"weather preference":float(request.POST['weather'])}
        other_infos={'gender': request.POST['gender'], 'age': request.POST['age'], 'workstatus':request.POST['workstatus'],
                      'spare_time':request.POST.getlist('timewith'),'reasonevents':request.POST['reasonevents']}
        user_state_graph.get_user_info(music_preference_list,movie_preference_list,food_preference_list,activity_preference_list,general_infos,other_infos,answers,sign_up_infos)

        return render(request, "welcome.html")
    else:
        return render(request, "questions.html")