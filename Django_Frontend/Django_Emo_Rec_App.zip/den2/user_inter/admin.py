from django.contrib import admin

from user_inter.models import User_info

admin.site.register(User_info)
