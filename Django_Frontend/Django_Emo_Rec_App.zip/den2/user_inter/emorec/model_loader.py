from keras.models import load_model
import fasttext as ft
import tensorflow as tf



def loader():
    print("____STARTING TO LOAD MODELS_____")
    m1 = ft.load_model("/Users/erenmac/Desktop/den2/user_inter/emorec/Models/multilabel_emotion.bin", label_prefix='__label__')
    m2 = ft.load_model("/Users/erenmac/Desktop/den2/user_inter/emorec/Models/binary_emotion.bin", label_prefix='__label__')

    m3 = load_model('/Users/erenmac/Desktop/den2/user_inter/emorec/Models/mfcc_7k.h5')
    m4 = load_model('/Users/erenmac/Desktop/den2/user_inter/emorec/Models/db_7k.h5')
    m5 = load_model('/Users/erenmac/Desktop/den2/user_inter/emorec/Models/wavelet_7k.h5')
    m6 = load_model('/Users/erenmac/Desktop/den2/user_inter/emorec/Models/Zero_7K')

    m7 = load_model('/Users/erenmac/Desktop/den2/user_inter/emorec/Models/mfcc_final_model.h5')
    m8 = load_model('/Users/erenmac/Desktop/den2/user_inter/emorec/Models/Db_final_model.h5')
    m9 = load_model('/Users/erenmac/Desktop/den2/user_inter/emorec/Models/Wavelet_final_model.h5')
    m10 = load_model('/Users/erenmac/Desktop/den2/user_inter/emorec/Models/Zero_Small')

    print("____ALL MODELS LOADED_____")
    return m1,m2,m3,m4,m5,m6,m7,m8,m9,m10