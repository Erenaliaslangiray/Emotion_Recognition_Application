from django.apps import AppConfig


class UserInterConfig(AppConfig):
    name = 'user_inter'
