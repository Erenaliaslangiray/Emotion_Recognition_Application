from django.urls import path,include
from django.views.generic.base import TemplateView
from django.contrib import admin
from . import views

urlpatterns = [
    path('login/', views.login_user, name='registration/login.html'),
    path('signup/', views.signup, name="signup"),
    #path('questions/', TemplateView.as_view(template_name='questions.html'), name='questions'),
    path('questions/', views.user_state, name="user_state"),
    #path('welcome/', views.check_welcome),
    path('welcome/', views.welcome_page),
    path('signup/choice/', views.default_user),
    #path('signup/', include('django.contrib.auth.urls')),

]
