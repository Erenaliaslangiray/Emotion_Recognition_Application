import speech_recognition as sr



def speechRecognizer(file_name='recognizer.wav'):
    recognizer = sr.Recognizer()
    with sr.WavFile(file_name) as source:
        audio = recognizer.record(source)
    try:
        print(recognizer.recognize_google(audio))
        return [recognizer.recognize_google(audio)]
    except:
        print(["Words are not identified!"])
        return (["Words are not identified!"])