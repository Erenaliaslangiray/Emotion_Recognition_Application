from django.http import HttpResponseRedirect
from django.shortcuts import render
from user_inter import user_state_graph
from user_inter.emorec import emorec as emo
from user_inter.emorec import soundcatcher,speech_recognizer


sign_up_infos={}

emotion_dict = { 0: "Neutral", 1 : "Angry", 2 : "Happy", 3 : "Sad"}

def home(request):
    return render(request, "home.html")

def signup(request):
    if request.method == "POST":

        user_info= {'name': request.POST['name'],'surname': request.POST['surname'],'email': request.POST['email'],'password': request.POST['psw']}
        if request.POST['psw']!=request.POST['psw-repeat']:
            print("passwords not equal")
            return render(request,"signup.html")
        elif user_state_graph.sign_up(user_info)==1:
            sign_up_infos.update(user_info)
            return HttpResponseRedirect("/home/signup/choice/")
        else:
            return render(request,"signup.html")
    else:
       return render(request, "signup.html")

def login_user(request):
    if request.method == "POST":
        login_info={"email":request.POST['email'],"password":request.POST['psw']}
        if user_state_graph.check_infos(login_info)==1:
            return HttpResponseRedirect("/home/welcome/")
        else:
            return render(request,"registration/login.html")
    else:
        return render(request, "registration/login.html")


def welcome_page(request):
    if "star-value" in request.POST:
        star_value=request.POST["star"]
        return render(request,"welcome.html")
    if user_state_graph.current_user_index == -1:
        return check_welcome(request)
    elif "print-btn" in request.POST:
        return print_from_button(request)
    elif "logout-btn" in request.POST:
       return logout_button(request)
    return render(request, "welcome.html")

def logout_button(request):
    user_state_graph.current_user_index = -1
    return HttpResponseRedirect("/home/")

def print_from_button(request):
    a = soundcatcher.Recorder()
    a.record()
    b = speech_recognizer.speechRecognizer()
    c = emo.Transformation()
    x = c.transformations(text=b)
    x = emotion_dict[x]
    c={"emotion":x + " - " + b[0]}
    return render(request,"welcome.html",c)

def default_user(request):
    if "default-user" in request.POST:
        return default_user_state(request)
    else:
        return render(request,"settings.html")

def default_user_state(request):
        music_preference_list = ['pop','rock','R&B','classical','turkish pop','turkish art music',"country","rap","punk","folk song","heavy metal"]
        movie_preference_list = ["action","adventure","comedy","crime","drama","horror","romance","mystery","science fiction","thriller","animation"]
        food_preference_list = ["turkish","mexican","italian","french","chinese"]
        activity_preference_list = ['travelling','friends','movie',"shopping"]
        answers = {
            "sad": [3, 3, 3,3, 3],
            "angry": [3, 3,3, 3,3],
            "happy": [3, 3,3, 3,3]}
        general_infos = {"animal": 0.0, "music": 0.0,
                         "children": 0.0,
                         "weather preference": 0.0}
        other_infos = {'gender': "male", 'age': "18-24",
                       'workstatus': "student",
                       'spare_time': "friend", 'reasonevents': "cost"}
        user_state_graph.get_user_info(music_preference_list, movie_preference_list, food_preference_list,
                                       activity_preference_list, general_infos, other_infos, answers, sign_up_infos)
        return HttpResponseRedirect("/home/welcome")


def user_state(request):
    if request.method == "POST":
        music_preference_list=request.POST.getlist('music')
        movie_preference_list=request.POST.getlist('movie')
        food_preference_list=request.POST.getlist('cuisine')
        activity_preference_list=request.POST.getlist('leisureact')
        answers={"sad":[int(request.POST['sad-eating']),int(request.POST['sad-talk']),int(request.POST['sad-music']),int(request.POST['sad-activity']),int(request.POST['sad-alone'])],
                 "angry":[int(request.POST['angry-eating']),int(request.POST['angry-talk']),int(request.POST['angry-music']),int(request.POST['angry-activity']),int(request.POST['angry-alone'])],
                 "happy":[int(request.POST['happy-eating']),int(request.POST['happy-talk']),int(request.POST['happy-music']),int(request.POST['happy-activity']),int(request.POST['happy-alone'])]}
        general_infos={"animal":float(request.POST['animal']), "music":float(request.POST['mood']),"children":float(request.POST['children']),"weather preference":float(request.POST['weather'])}
        other_infos={'gender': request.POST['gender'], 'age': request.POST['age'], 'workstatus':request.POST['workstatus'],
                      'spare_time':request.POST.getlist('timewith'),'reasonevents':request.POST['reasonevents']}
        user_state_graph.get_user_info(music_preference_list,movie_preference_list,food_preference_list,activity_preference_list,general_infos,other_infos,answers,sign_up_infos)
        return HttpResponseRedirect("/home/welcome")
    else:
        return render(request, "questions.html")

def check_welcome(request):
    if user_state_graph.current_user_index==-1:
        return HttpResponseRedirect("http://127.0.0.1:8000/home/login/")
    else:
        return render(request,"welcome.html")
